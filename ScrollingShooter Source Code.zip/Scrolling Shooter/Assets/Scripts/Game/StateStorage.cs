﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StateStorage : MonoBehaviour {
	public static int game_dificulty = 2;
	public static int score;
	public static bool game_over;
	public static int enemies_killed;
	public static Vector3 previous_kill;
}
