﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GroupDeath : MonoBehaviour {

	public int num_destroyed;
	public Transform power_up;
}
