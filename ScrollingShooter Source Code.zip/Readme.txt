README

Z to fire. 
WSAD or arrow keys to move.

Created on Unity2017
